import { useEffect, useState } from 'react';
import { Search, User } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Profile, House } from '../types';

export default function Members() {
  const [members, setMembers] = useState<(Profile & { house?: House })[]>([]);
  const [filteredMembers, setFilteredMembers] = useState<(Profile & { house?: House })[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchMembers();
  }, []);

  useEffect(() => {
    filterMembers();
  }, [searchQuery, members]);

  const fetchMembers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select(`
          *,
          house:houses(*)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setMembers(data || []);
      setFilteredMembers(data || []);
    } catch (error) {
      console.error('Error fetching members:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterMembers = () => {
    if (!searchQuery) {
      setFilteredMembers(members);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = members.filter(
      (member) =>
        member.full_name.toLowerCase().includes(query) ||
        member.email.toLowerCase().includes(query) ||
        member.business?.toLowerCase().includes(query) ||
        member.industry?.toLowerCase().includes(query)
    );
    setFilteredMembers(filtered);
  };

  return (
    <div className="p-8 space-y-6 animate-fade-in relative overflow-hidden">
      <div className="absolute top-[-150px] right-[-150px] w-[700px] h-[700px] gradient-blob-green opacity-20" />
      <div className="absolute bottom-[-100px] left-[-100px] w-[500px] h-[500px] gradient-blob-teal opacity-25" />

      <div className="flex items-center justify-between animate-slide-up relative z-10">
        <div>
          <h1 className="text-3xl font-bold mb-2">Members</h1>
          <p className="text-[#9CA3AF]">WeVysya member profiles and details</p>
        </div>
      </div>

      <div className="bg-card rounded-2xl p-6 border border-gray-800/50 relative z-10 backdrop-blur-xl">
        <div className="flex items-center space-x-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
            <input
              type="text"
              placeholder="Search members..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-xl bg-[#0F1412] border border-gray-800 text-white placeholder-gray-600 focus:outline-none input-glow transition-all"
            />
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-48 bg-[#0F1412] rounded-2xl animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMembers.map((member, index) => (
              <div
                key={member.id}
                className="bg-[#0F1412] rounded-2xl p-6 border border-gray-800/50 hover:border-[#6EE7B7]/30 transition-all duration-300 group relative overflow-hidden cursor-pointer animate-slide-up backdrop-blur-xl"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <div className="absolute -right-8 -top-8 w-32 h-32 gradient-blob-teal opacity-0 group-hover:opacity-15 transition-all duration-500" />
                <div className="relative z-10">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 rounded-xl flex items-center justify-center ring-2 ring-[#6EE7B7]/30" style={{ backgroundColor: '#14532D' }}>
                        <User className="w-6 h-6" style={{ color: '#6EE7B7' }} />
                      </div>
                      <div>
                        <h3 className="font-semibold">{member.full_name}</h3>
                        <p className="text-xs text-[#9CA3AF] capitalize">{member.role.replace('_', ' ')}</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div>
                      <span className="text-[#6B7280]">Email:</span>
                      <p className="text-[#9CA3AF] truncate">{member.email}</p>
                    </div>
                    {member.business && (
                      <div>
                        <span className="text-[#6B7280]">Business:</span>
                        <p className="text-[#9CA3AF]">{member.business}</p>
                      </div>
                    )}
                    {member.industry && (
                      <div>
                        <span className="text-[#6B7280]">Industry:</span>
                        <p className="text-[#9CA3AF]">{member.industry}</p>
                      </div>
                    )}
                    {member.house && (
                      <div>
                        <span className="text-[#6B7280]">House:</span>
                        <p className="text-[#9CA3AF]">{member.house.name}</p>
                      </div>
                    )}
                    {member.keywords && member.keywords.length > 0 && (
                      <div>
                        <span className="text-[#6B7280]">Keywords:</span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {member.keywords.slice(0, 3).map((keyword, i) => (
                            <span
                              key={i}
                              className="px-2 py-1 rounded text-xs"
                              style={{ backgroundColor: 'rgba(110, 231, 183, 0.1)', color: '#6EE7B7' }}
                            >
                              {keyword}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {filteredMembers.length === 0 && (
          <div className="text-center py-12 text-[#6B7280]">
            No members found
          </div>
        )}
      </div>
    </div>
  );
}
