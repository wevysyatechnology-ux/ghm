import { useEffect, useState } from 'react';
import { Search, Plus, Filter } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { House } from '../types';

export default function Houses() {
  const { profile } = useAuth();
  const [houses, setHouses] = useState<House[]>([]);
  const [filteredHouses, setFilteredHouses] = useState<House[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  const canAddHouse = profile?.role === 'super_admin' || profile?.role === 'global_admin';

  useEffect(() => {
    fetchHouses();
  }, []);

  useEffect(() => {
    filterHouses();
  }, [searchQuery, houses]);

  const fetchHouses = async () => {
    try {
      const { data, error } = await supabase
        .from('houses')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setHouses(data || []);
      setFilteredHouses(data || []);
    } catch (error) {
      console.error('Error fetching houses:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterHouses = () => {
    if (!searchQuery) {
      setFilteredHouses(houses);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = houses.filter(
      (house) =>
        house.name.toLowerCase().includes(query) ||
        house.state.toLowerCase().includes(query) ||
        house.city.toLowerCase().includes(query) ||
        house.zone.toLowerCase().includes(query)
    );
    setFilteredHouses(filtered);
  };

  return (
    <div className="p-8 space-y-6 animate-fade-in relative overflow-hidden">
      <div className="absolute top-[-100px] left-[-100px] w-[600px] h-[600px] gradient-blob-teal opacity-25" />
      <div className="absolute bottom-[-150px] right-[-150px] w-[700px] h-[700px] gradient-blob-green opacity-20" />

      <div className="flex items-center justify-between animate-slide-up relative z-10">
        <div>
          <h1 className="text-3xl font-bold mb-2">Houses</h1>
          <p className="text-[#9CA3AF]">Manage WeVysya houses across zones</p>
        </div>
        {canAddHouse && (
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center space-x-2 px-6 py-3 rounded-xl font-medium transition-all-smooth hover:brightness-110"
            style={{ backgroundColor: '#4ADE80', color: '#0B0F0E' }}
          >
            <Plus className="w-5 h-5" />
            <span>Add House</span>
          </button>
        )}
      </div>

      <div className="bg-card rounded-2xl p-6 border border-gray-800/50 relative z-10 backdrop-blur-xl">
        <div className="flex items-center space-x-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
            <input
              type="text"
              placeholder="Search houses..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-xl bg-[#0F1412] border border-gray-800 text-white placeholder-gray-600 focus:outline-none input-glow transition-all"
            />
          </div>
          <button className="flex items-center space-x-2 px-4 py-3 rounded-xl bg-[#0F1412] border border-gray-800 text-[#9CA3AF] hover:text-white hover:border-gray-700 transition-all">
            <Filter className="w-5 h-5" />
            <span>Filter</span>
          </button>
        </div>

        {loading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-16 bg-[#0F1412] rounded-xl animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-800">
                  <th className="text-left py-4 px-4 text-[#9CA3AF] font-medium text-sm">House Name</th>
                  <th className="text-left py-4 px-4 text-[#9CA3AF] font-medium text-sm">State</th>
                  <th className="text-left py-4 px-4 text-[#9CA3AF] font-medium text-sm">City</th>
                  <th className="text-left py-4 px-4 text-[#9CA3AF] font-medium text-sm">Zone</th>
                  <th className="text-left py-4 px-4 text-[#9CA3AF] font-medium text-sm">Email</th>
                  <th className="text-left py-4 px-4 text-[#9CA3AF] font-medium text-sm">Mobile</th>
                  <th className="text-left py-4 px-4 text-[#9CA3AF] font-medium text-sm">Created</th>
                </tr>
              </thead>
              <tbody>
                {filteredHouses.map((house) => (
                  <tr key={house.id} className="border-b border-gray-800/50 hover:bg-[#0F1412] transition-all-smooth cursor-pointer">
                    <td className="py-4 px-4 font-medium">{house.name}</td>
                    <td className="py-4 px-4 text-[#9CA3AF]">{house.state}</td>
                    <td className="py-4 px-4 text-[#9CA3AF]">{house.city}</td>
                    <td className="py-4 px-4">
                      <span className="px-3 py-1 rounded-lg text-sm" style={{ backgroundColor: 'rgba(110, 231, 183, 0.1)', color: '#6EE7B7' }}>
                        {house.zone}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-[#9CA3AF]">{house.email || '-'}</td>
                    <td className="py-4 px-4 text-[#9CA3AF]">{house.mobile || '-'}</td>
                    <td className="py-4 px-4 text-[#9CA3AF] text-sm">
                      {new Date(house.created_at).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {filteredHouses.length === 0 && (
              <div className="text-center py-12 text-[#6B7280]">
                No houses found
              </div>
            )}
          </div>
        )}
      </div>

      {showAddModal && (
        <AddHouseModal
          onClose={() => setShowAddModal(false)}
          onSuccess={() => {
            setShowAddModal(false);
            fetchHouses();
          }}
        />
      )}
    </div>
  );
}

function AddHouseModal({ onClose, onSuccess }: { onClose: () => void; onSuccess: () => void }) {
  const [formData, setFormData] = useState({
    name: '',
    state: '',
    city: '',
    zone: '',
    email: '',
    mobile: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const { error } = await supabase.from('houses').insert([formData]);
      if (error) throw error;
      onSuccess();
    } catch (err: any) {
      setError(err.message || 'Failed to create house');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 animate-fade-in">
      <div className="bg-card rounded-2xl p-8 border border-gray-800/50 max-w-2xl w-full max-h-[90vh] overflow-y-auto animate-slide-up">
        <h2 className="text-2xl font-bold mb-6">Add New House</h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2 text-[#9CA3AF]">House Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-3 rounded-xl bg-[#0F1412] border border-gray-800 text-white placeholder-gray-600 focus:outline-none input-glow"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2 text-[#9CA3AF]">Zone</label>
              <input
                type="text"
                value={formData.zone}
                onChange={(e) => setFormData({ ...formData, zone: e.target.value })}
                className="w-full px-4 py-3 rounded-xl bg-[#0F1412] border border-gray-800 text-white placeholder-gray-600 focus:outline-none input-glow"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2 text-[#9CA3AF]">State</label>
              <input
                type="text"
                value={formData.state}
                onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                className="w-full px-4 py-3 rounded-xl bg-[#0F1412] border border-gray-800 text-white placeholder-gray-600 focus:outline-none input-glow"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2 text-[#9CA3AF]">City</label>
              <input
                type="text"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                className="w-full px-4 py-3 rounded-xl bg-[#0F1412] border border-gray-800 text-white placeholder-gray-600 focus:outline-none input-glow"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2 text-[#9CA3AF]">Email</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-3 rounded-xl bg-[#0F1412] border border-gray-800 text-white placeholder-gray-600 focus:outline-none input-glow"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2 text-[#9CA3AF]">Mobile</label>
              <input
                type="tel"
                value={formData.mobile}
                onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                className="w-full px-4 py-3 rounded-xl bg-[#0F1412] border border-gray-800 text-white placeholder-gray-600 focus:outline-none input-glow"
              />
            </div>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-red-900/20 border border-red-800/50 text-red-400 text-sm">
              {error}
            </div>
          )}

          <div className="flex space-x-4 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 rounded-xl bg-[#0F1412] border border-gray-800 text-white hover:bg-[#14532D] transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-6 py-3 rounded-xl font-medium transition-all disabled:opacity-50 glow-green-sm hover:glow-green"
              style={{ backgroundColor: '#4ADE80', color: '#0B0F0E' }}
            >
              {loading ? 'Creating...' : 'Create House'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
