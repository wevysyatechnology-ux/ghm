import { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Login from './components/Login';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Houses from './components/Houses';
import Members from './components/Members';
import Users from './components/Users';
import Links from './components/Links';
import Deals from './components/Deals';
import I2WE from './components/I2WE';
import Attendance from './components/Attendance';
import Reports from './components/Reports';
import Footer from './components/Footer';

function AppContent() {
  const { user, profile, loading } = useAuth();
  const [currentView, setCurrentView] = useState('dashboard');

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#0B0F0E' }}>
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-[#6EE7B7] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-[#9CA3AF]">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user || !profile) {
    return <Login />;
  }

  return (
    <div className="flex min-h-screen" style={{ backgroundColor: '#0B0F0E' }}>
      <Sidebar currentView={currentView} onViewChange={setCurrentView} />
      <main className="flex-1 overflow-y-auto flex flex-col">
        <div className="flex-1">
          {currentView === 'dashboard' && <Dashboard />}
          {currentView === 'houses' && <Houses />}
          {currentView === 'members' && <Members />}
          {currentView === 'users' && <Users />}
          {currentView === 'links' && <Links />}
          {currentView === 'deals' && <Deals />}
          {currentView === 'i2we' && <I2WE />}
          {currentView === 'attendance' && <Attendance />}
          {currentView === 'reports' && <Reports />}
        </div>
        <Footer />
      </main>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
